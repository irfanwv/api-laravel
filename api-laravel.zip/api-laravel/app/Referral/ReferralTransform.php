<?php

namespace App\Referral;

use League\Fractal\TransformerAbstract;

class ReferralTransform extends TransformerAbstract
{
    protected $availableIncludes = [
    ];

    public function transform (ReferralTransform $referraltransform)
    {
        $params = [
        ];

        return $params;
    }
}
