<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setRoutes(
    unserialize(base64_decode('TzozNDoiSWxsdW1pbmF0ZVxSb3V0aW5nXFJvdXRlQ29sbGVjdGlvbiI6NDp7czo5OiIAKgByb3V0ZXMiO2E6Mjp7czozOiJHRVQiO2E6MTp7czo1OiJpbmRleCI7TzoyNDoiSWxsdW1pbmF0ZVxSb3V0aW5nXFJvdXRlIjo3OntzOjY6IgAqAHVyaSI7czo1OiJpbmRleCI7czoxMDoiACoAbWV0aG9kcyI7YToyOntpOjA7czozOiJHRVQiO2k6MTtzOjQ6IkhFQUQiO31zOjk6IgAqAGFjdGlvbiI7YTo1OntzOjQ6InVzZXMiO3M6NDA6IkFwcFxIdHRwXENvbnRyb2xsZXJzXENpdHlDb250cm9sbGVyQHRlc3QiO3M6MTA6ImNvbnRyb2xsZXIiO3M6NDA6IkFwcFxIdHRwXENvbnRyb2xsZXJzXENpdHlDb250cm9sbGVyQHRlc3QiO3M6OToibmFtZXNwYWNlIjtzOjIwOiJBcHBcSHR0cFxDb250cm9sbGVycyI7czo2OiJwcmVmaXgiO047czo1OiJ3aGVyZSI7YTowOnt9fXM6MTE6IgAqAGRlZmF1bHRzIjthOjA6e31zOjk6IgAqAHdoZXJlcyI7YTowOnt9czoxMzoiACoAcGFyYW1ldGVycyI7TjtzOjE3OiIAKgBwYXJhbWV0ZXJOYW1lcyI7Tjt9fXM6NDoiSEVBRCI7YToxOntzOjU6ImluZGV4IjtyOjQ7fX1zOjEyOiIAKgBhbGxSb3V0ZXMiO2E6MTp7czo5OiJIRUFEaW5kZXgiO3I6NDt9czoxMToiACoAbmFtZUxpc3QiO2E6MDp7fXM6MTM6IgAqAGFjdGlvbkxpc3QiO2E6MTp7czo0MDoiQXBwXEh0dHBcQ29udHJvbGxlcnNcQ2l0eUNvbnRyb2xsZXJAdGVzdCI7cjo0O319'))
);
