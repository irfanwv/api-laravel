@extends('layouts.email')

@section('title', $subject)

@section('body')
<p>activation link for a studio</p>
@stop

