@extends('layouts.email')

@section('title', $subject)

@section('body')
<p>a new user has registered with us</p>
@stop

