<?php

return [
    /*
    |--------------------------------------------------------------------------
    | API Secret Key
    |--------------------------------------------------------------------------
    |
    | The api secret key to access Mailchimp. If you don't know the API key, find it here:
    | "http://kb.mailchimp.com/accounts/management/about-api-keys#Find-or-Generate-Your-API-Key"
    |
    */

    'apikey' => 'debf917360955933a7d0796688e026a6-us12',
];